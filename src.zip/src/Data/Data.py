links = [
    {

        'id': 1,
        'url': u'www.google.rs'
    },
    {
        'id': 2,
        'url': u'www.google.rs'
    }
]